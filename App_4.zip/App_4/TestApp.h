#pragma once
class TestApp
{
public:
	void runAllTests();
};

