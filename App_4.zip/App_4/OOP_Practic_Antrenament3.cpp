#include "OOP_Practic_Antrenament3.h"

OOP_Practic_Antrenament3::OOP_Practic_Antrenament3(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
