#include "GuiApp.h"


void GuiApp::initGUI() {
	tabel->setSelectionBehavior(QAbstractItemView::SelectRows);
	tabel->setModel(model);
	resize(1300, 400);
	QHBoxLayout* lyMain = new QHBoxLayout;
	QVBoxLayout* lyDr = new QVBoxLayout;
	setLayout(lyMain);

	lblTitlu->setText("TITILU:");
	lblGen->setText("GEN:");
	lblArtist->setText("ARTIST:");

	lyDr->addWidget(lblTitlu);
	lyDr->addWidget(leTitlu);

	lyDr->addWidget(lblArtist);
	lyDr->addWidget(leArtist);

	lyDr->addWidget(lblGen);
	lyDr->addWidget(leGen);

	lyDr->addStretch();

	lyDr->addWidget(btnAdd);
	lyDr->addWidget(btnStergere);


	lyMain->addWidget(tabel);
	lyMain->addLayout(lyDr);
}

void GuiApp::initConnection() {
	QObject::connect(tabel->selectionModel(), &QItemSelectionModel::selectionChanged, [&]() {
		if (tabel->selectionModel()->selectedIndexes().isEmpty()) {
			leTitlu->setText("");
			leArtist->setText("");
			leGen->setText("");
			id = -1;
		}
		else {
			int row = tabel->selectionModel()->selectedIndexes().at(0).row();
			auto c1 = tabel->model()->index(row, 0);
			auto c2 = tabel->model()->index(row, 1);
			auto c3 = tabel->model()->index(row, 2);
			auto c4 = tabel->model()->index(row, 3);

			auto val1 = tabel->model()->data(c1, Qt::DisplayRole).toInt();
			auto val2 = tabel->model()->data(c2, Qt::DisplayRole).toString();
			auto val3 = tabel->model()->data(c3, Qt::DisplayRole).toString();
			auto val4 = tabel->model()->data(c4, Qt::DisplayRole).toString();

			id = val1;
			leTitlu->setText(val2);
			leArtist->setText(val3);
			leGen->setText(val4);

		}
		
		});

	QObject::connect(btnAdd, &QPushButton::clicked, [&]() {
		if (id == -1 || leTitlu->text()=="" || leArtist->text() == "" || leGen->text() == "") {
			QMessageBox::information(nullptr,"Info adaugare","Selectati o melodie, datele nu pot fi nule");
		}
		else {

			serv.adaugare(leTitlu->text().toStdString(),leArtist->text().toStdString(),leGen->text().toStdString());

			loadData();
		}

		leTitlu->setText("");
		leArtist->setText("");
		leGen->setText("");
		id = -1;
		
		});

	QObject::connect(btnStergere, &QPushButton::clicked, [&]() {
		if (id == -1) {
			QMessageBox::information(nullptr, "Info stergere", "Selectati o melodie");
		}
		else {
			
			serv.stergere(id);

			loadData();
		}

		leTitlu->setText("");
		leArtist->setText("");
		leGen->setText("");
		id = -1;

		});
}

void GuiApp::loadData() {
	model->setMelodii(serv.getAllM());
}
