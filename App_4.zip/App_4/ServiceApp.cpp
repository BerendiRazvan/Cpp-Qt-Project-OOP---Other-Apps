#include "ServiceApp.h"
#include <algorithm>


bool cmp(Melodie& m1,Melodie& m2) {
    return m1.getArtist() < m2.getArtist();
}


vector<Melodie>& ServiceApp::getAllM()
{
    sort(repo.getAll().begin(),repo.getAll().end(),cmp);
    return repo.getAll();
}

void ServiceApp::adaugare(string titlu, string artist, string gen)
{
    int idUnic = 1,ok=0;
    while (ok == 0) {
        for (auto& m : repo.getAll())
            if (m.getId() == idUnic)
                ok = 1;
        if (ok == 1)
            idUnic++, ok = 0;
        else {
            break;
        }
    
    }
    
    Melodie m{ idUnic,titlu,artist,gen };
    repo.adaugare(m);

}

void ServiceApp::stergere(int id)
{
    repo.stergere(id);
}
