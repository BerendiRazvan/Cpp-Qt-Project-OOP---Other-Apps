#pragma once
#include <vector>

#include "DomainApp.h"

using namespace std;


class RepositoryApp{
private:
	vector<Melodie> lista;
	string numeFis;

	void loadD();
	void saveD();

public:

	RepositoryApp() = default;
	RepositoryApp(string numeFis) :numeFis{ numeFis } {
		loadD();
	}
	RepositoryApp(const RepositoryApp& ot) = delete;

	vector<Melodie>& getAll();
	void adaugare(const Melodie& m);
	void stergere(const int id);


};

