#include "DomainApp.h"

int Melodie::getId()
{
    return id;
}

string Melodie::getTitlu()
{
    return titlu;
}

string Melodie::getArtist()
{
    return artist;
}

string Melodie::getGen()
{
    return gen;
}
