#pragma once
#include <string>

using namespace std;


class Melodie{
private:
	int id;
	string titlu, artist, gen;

public:

	Melodie() = default;
	Melodie(int id, string titlu, string artist, string gen) :id{ id }, titlu{ titlu }, artist{ artist }, gen{ gen }{}

	int getId();
	string getTitlu();
	string getArtist();
	string getGen();

};

