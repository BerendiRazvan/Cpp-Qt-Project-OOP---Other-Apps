#pragma once

#include "RepositoryApp.h"

class ServiceApp {
private:
	RepositoryApp& repo;


public:
	ServiceApp() = default;
	ServiceApp(RepositoryApp& repo) :repo{ repo } {}
	ServiceApp(const ServiceApp& ot) = delete;

	//alte fct.

	vector<Melodie>& getAllM();
	
	void adaugare(string titlu,string artist,string gen);
	void stergere(int id);

};

