#pragma once

#include <qwidget.h>
#include <qtableview.h>
#include <qabstracttablemodel>
#include <qstring.h>
#include <qlayout.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qobject.h>
#include <qmessagebox.h>


#include "ServiceApp.h"


class MyModel :public QAbstractTableModel {
private:
	vector<Melodie> lista;
	ServiceApp& serv;

public:
	MyModel() = default;
	MyModel(ServiceApp& serv) :serv{ serv }, lista{ serv.getAllM() }{}

	int rowCount(const QModelIndex& parent = QModelIndex()) const override {
		return lista.size();
	}
	int columnCount(const QModelIndex& parent = QModelIndex()) const override {
		return 6;
	}

	QVariant data(const QModelIndex& index = QModelIndex(),int role=Qt::DisplayRole) const override {
		if (role == Qt::DisplayRole) {
			Melodie m = lista[index.row()];

			if (index.column() == 0)
				return m.getId();

			if (index.column() == 1)
				return QString::fromStdString(m.getTitlu());

			if (index.column() == 2)
				return QString::fromStdString(m.getArtist());

			if (index.column() == 3)
				return QString::fromStdString(m.getGen());

			if (index.column() == 4) {
				int nr = 0;
				for (auto& ms : serv.getAllM())
					if (ms.getArtist() == m.getArtist())
						nr++;
				return nr;
			}

			if (index.column() == 5) {
				int nr = 0;
				for (auto& ms : serv.getAllM())
					if (ms.getGen() == m.getGen())
						nr++;
				return nr;
			}
		
		}
	
		return QVariant{};
	}

	void setMelodii(const vector<Melodie>& m) {
		lista = m;

		QModelIndex topLeft = createIndex(0, 0);
		QModelIndex bottumRight = createIndex(rowCount(), columnCount());
		emit dataChanged(topLeft, bottumRight);
		emit layoutChanged();
	}

};




class GuiApp :public QWidget {
private:
	ServiceApp& serv;

	QTableView* tabel = new QTableView;
	MyModel* model = new MyModel(serv);


	QPushButton* btnAdd = new QPushButton("&Adaugare");
	QPushButton* btnStergere = new QPushButton("&Stergere");

	QLabel* lblTitlu = new QLabel;
	QLabel* lblArtist = new QLabel;
	QLabel* lblGen = new QLabel;

	QLineEdit* leTitlu = new QLineEdit;
	QLineEdit* leArtist = new QLineEdit;
	QLineEdit* leGen = new QLineEdit;
	
	int id = -1;


	void initGUI();
	void initConnection();
	void loadData();

public:

	GuiApp() = default;
	GuiApp(ServiceApp& serv) :serv{ serv } {
		initGUI();
		initConnection();
		loadData();
	}
	GuiApp(const GuiApp& ot) = delete;


};

