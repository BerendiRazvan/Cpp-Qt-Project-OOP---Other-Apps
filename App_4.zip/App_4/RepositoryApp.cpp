#include "RepositoryApp.h"

#include <vector>
#include <exception>
#include <fstream>

using namespace std;

void RepositoryApp::loadD(){
    ifstream in(numeFis);

    if (!in.is_open())
        throw exception("Fisierul pt. citire nu poate fi deschis");
    
    while (!in.eof()) {
        string id, titlu, artist, gen;
        if (in.eof())break;
        getline(in,id,';');

        if (in.eof())break;
        getline(in, titlu, ';');

        if (in.eof())break;
        getline(in, artist, ';');

        if (in.eof())break;
        getline(in, gen, '\n');

        Melodie m{ stoi(id),titlu,artist,gen };
        lista.push_back(m);
    
    }

    in.close();
}

void RepositoryApp::saveD(){
    ofstream out(numeFis);

    if(!out.is_open())
        throw exception("Fisierul pt. scriere nu poate fi deschis");

    for (auto& m : lista)
        out << m.getId() << ";" << m.getTitlu() << ";" << m.getArtist() << ";" << m.getGen() << "\n";

    out.close();
}


vector<Melodie>& RepositoryApp::getAll()
{
    return lista;
}

void RepositoryApp::adaugare(const Melodie& m)
{
    lista.push_back(m);
    saveD();
}

void RepositoryApp::stergere(const int id)
{
    for (int i = 0; i < lista.size(); i++)
        if (lista[i].getId() == id)
            lista.erase(lista.begin()+i);
    saveD();
}
