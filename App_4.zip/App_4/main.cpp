#include "OOP_Practic_Antrenament3.h"
#include <QtWidgets/QApplication>

#include "TestApp.h"
#include "GuiApp.h"
#include "RepositoryApp.h"
#include "ServiceApp.h"


void runApp(int argc, char* argv[]) {

    QApplication a(argc, argv);
    
    //Repostory App
    RepositoryApp repo{"data.txt"};

    //Service App
    ServiceApp serv{ repo };
    
    //GUI App
    GuiApp consola{ serv };
    consola.show();
    
    a.exec();

}


int main(int argc, char *argv[])
{
    //Testare App
    TestApp teste;
    teste.runAllTests();


    runApp(argc,argv);

    return 0;
}
