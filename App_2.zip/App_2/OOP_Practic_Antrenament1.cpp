#include "OOP_Practic_Antrenament1.h"

OOP_Practic_Antrenament1::OOP_Practic_Antrenament1(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
