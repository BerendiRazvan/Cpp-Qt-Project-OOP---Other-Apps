#pragma once
class TestApp{

private:

public:

	void runAllTest();


};

