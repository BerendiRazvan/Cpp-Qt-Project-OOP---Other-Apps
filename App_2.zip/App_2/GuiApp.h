#pragma once
#include "ServApp.h"

#include "qwidget.h"
#include <QAbstractTableModel>
#include <qtableview.h>
#include <qlayout.h>
#include <qpushbutton.h>
#include <qlineedit.h>
#include <qmessagebox.h>
#include <qlabel.h>
#include <qobject.h>
#include <qslider.h>

class MyModel : public QAbstractTableModel {
private:
	vector<Produs> lista;
	ServApp& serv;
public:
	MyModel() = default;
	MyModel(ServApp& serv) :serv{serv}, lista{ serv.getAllP() } {};

	int rowCount(const QModelIndex& parent = QModelIndex())const override {
		return lista.size();
	}

	int columnCount(const QModelIndex& parent = QModelIndex())const override {
		return 5;
	}


	QVariant data(const QModelIndex& index = QModelIndex(), int role = Qt::DisplayRole)const override {
		if (role == Qt::DisplayRole) {
			Produs p = lista[index.row()];
			if (index.column() == 0)
				return p.getId();

			if (index.column() == 1)
				return QString::fromStdString(p.getNume());

			if (index.column() == 2)
				return QString::fromStdString(p.getTip());

			if (index.column() == 3)
				return p.getPret();

			if (index.column() == 4)
				return p.getNrVocale();

		}
		if (role == Qt::BackgroundRole) {
			Produs pr = lista[index.row()];
			for (auto& p : serv.getF()) {
				if (p.getId() == pr.getId())
					return QBrush(Qt::red);
				

			}
		}


		return QVariant{};

	}

	void setProdus() {
		this->lista = serv.getAllP();
		QModelIndex topLeft = createIndex(0, 0);
		QModelIndex bottomRight = createIndex(rowCount(), columnCount());
		emit dataChanged(topLeft, bottomRight);
		emit layoutChanged();
	}

};




class GuiApp:public QWidget{
private:

	ServApp& serv;
	QTableView* tabel = new QTableView();
	MyModel* model = new MyModel(serv);

	QPushButton* btnAdd = new QPushButton("&Add produs");
	QLineEdit* editID = new QLineEdit;
	QLineEdit* editNume = new QLineEdit;
	QLineEdit* editTip = new QLineEdit;
	QLineEdit* editPret = new QLineEdit;
	QSlider* slider = new QSlider;

	void loadDataTable();
	void initGUI();
	void initConnect();
	void ferestre();
public:


	GuiApp() = default;

	GuiApp(ServApp& serv) :serv{serv} {
		initGUI();
		initConnect();
		loadDataTable();

	};

	GuiApp(const ServApp& ot) = delete;

};



