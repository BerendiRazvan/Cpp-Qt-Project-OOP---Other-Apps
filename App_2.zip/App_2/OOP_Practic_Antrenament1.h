#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_OOP_Practic_Antrenament1.h"

class OOP_Practic_Antrenament1 : public QMainWindow
{
    Q_OBJECT

public:
    OOP_Practic_Antrenament1(QWidget *parent = Q_NULLPTR);

private:
    Ui::OOP_Practic_Antrenament1Class ui;
};
