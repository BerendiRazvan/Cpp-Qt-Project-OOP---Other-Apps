#include "TestApp.h"
#include "DomainApp.h"
#include "RepoApp.h"
#include "ServApp.h"


#include "qdebug.h"

void testDomain() {

	//testare
}

void testRepo() {
	RepoApp repo{ "datatest.txt" };
	assert(repo.getAll().size() == 10);
}

void testSerrvice() {

	//testare
}


void TestApp::runAllTest()
{

	testDomain();
	testRepo();
	testSerrvice();


	qDebug() << "All tests passed\n";
}
