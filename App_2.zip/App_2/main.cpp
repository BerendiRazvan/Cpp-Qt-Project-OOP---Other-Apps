#include "OOP_Practic_Antrenament1.h"
#include <QtWidgets/QApplication>

#include "TestApp.h"
#include "GuiApp.h"
#include "DomainApp.h"
#include "RepoApp.h"
#include "ServApp.h"

void runApp(int argc, char* argv[]){

    QApplication a(argc, argv);

    //Repository App
    RepoApp repo{"data.txt"};

    //Service App
    ServApp serv{ repo };

    //GUI App
    GuiApp console{serv};
    console.show();

    a.exec();
}


int main(int argc, char *argv[])
{
    //Test App
    TestApp t{};
    t.runAllTest();
   
    
    runApp(argc,argv);

    return 0;
}
