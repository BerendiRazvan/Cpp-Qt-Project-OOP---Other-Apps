#pragma once
#include <string>

using namespace std;

class Produs {
private:
	int id;
	string nume;
	string tip;
	double pret;

public:

	Produs() = default;
	Produs(int id, string nume, string tip, double pret) :id{ id }, nume{ nume }, tip{ tip }, pret{ pret } {}


	int getId() const;
	string getNume()const;
	string getTip()const;
	double getPret()const;
	int getNrVocale()const;
};

