#include "RepoApp.h"
#include <fstream>
#include <exception>

void RepoApp::load(){
	ifstream in(numeFis);
	if (!in.is_open())
		throw exception();
	
	while (!in.eof()) {
		string id, nume, tip, pret;
		if (in.eof())break;
		getline(in, id, ';');
		
		if(in.eof())break;
		getline(in, nume, ';');

		if (in.eof())break;
		getline(in, tip, ';');

		if (in.eof())break;
		getline(in, pret, '\n');

		Produs p{ stoi(id),nume,tip,stod(pret) };

		lista.push_back(p);

	}

	in.close();

}

void RepoApp::save()
{
	ofstream out(numeFis);

	if (!out.is_open())
		throw exception();

	for (auto& p : lista)
		out << p.getId() << ";" << p.getNume() << ";" << p.getTip() << ";" << p.getPret() << "\n";

	out.close();
}

vector<Produs>& RepoApp::getAll(){
	return lista;
}

void RepoApp::add(const Produs& p) {

	lista.push_back(p);

	save();
}