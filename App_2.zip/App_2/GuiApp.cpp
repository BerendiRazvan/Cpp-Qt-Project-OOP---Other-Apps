#include "GuiApp.h"

void GuiApp::initGUI(){
	tabel->setSelectionBehavior(QAbstractItemView::SelectRows);
	tabel->setModel(model);

	QHBoxLayout* lyMain = new QHBoxLayout;
	QVBoxLayout* lySt= new QVBoxLayout;

	QVBoxLayout* lyDr = new QVBoxLayout;


	setLayout(lyMain);
	lySt->addWidget(tabel);

	QLabel* lblID = new QLabel;
	QLabel* lblNume = new QLabel;
	QLabel* lblTip = new QLabel;
	QLabel* lblPret = new QLabel;
	lblID->setText("ID produs : ");
	lblNume->setText("NUME produs : ");
	lblTip->setText("TIP produs : ");
	lblPret->setText("PRET produs : ");
	lyDr->addWidget(lblID);

	lyDr->addWidget(editID);

	lyDr->addWidget(lblNume);
	lyDr->addWidget(editNume);

	lyDr->addWidget(lblTip);
	lyDr->addWidget(editTip);
	lyDr->addWidget(lblPret);
	lyDr->addWidget(editPret);


	lyMain->addWidget(slider);
	lyDr->addWidget(btnAdd);

	lyMain->addLayout(lySt);
	lyMain->addLayout(lyDr);

}

void GuiApp::ferestre() {

	vector<string> tipuri;

	for (auto& p : serv.getAllP()) {
		int ok = 0;
		for (auto t : tipuri) {
			if (t == p.getTip())
				ok = 1;
		}
		if (ok == 0)
			tipuri.push_back(p.getTip());
	}
	for (auto t : tipuri) {
		QWidget* window = new QWidget;
		window->resize(300, 70);
		
		QVBoxLayout* ly = new QVBoxLayout;
		window->setLayout(ly);
		QLabel* nr = new QLabel;

		int numar = 0;
		for (auto& p : serv.getAllP()) {
			if (p.getTip() == t)
				numar++;
		}
		nr->setText(QString::fromStdString(t) + ": " + QString::fromStdString(to_string(numar)));

		ly->addWidget(nr);

		window->show();

		QObject::connect(btnAdd, &QPushButton::clicked, [window]() {
			window->close();
			});


	}

}

void GuiApp::loadDataTable() {
	model->setProdus();
	ferestre();
}

void GuiApp::initConnect(){
	QObject::connect(btnAdd, &QPushButton::clicked, [&]() {
		
		string id = editID->text().toStdString();
		string nume = editNume->text().toStdString();
		string tip = editTip->text().toStdString();
		string pret = editPret->text().toStdString();
		try {
			serv.adaugare(stoi(id), nume, tip, stod(pret));
		}
		catch (exception& except) {
			QMessageBox::information(nullptr,"Info adaugare",except.what());
		}


		editID->setText("");
		editNume->setText("");
		editTip->setText("");
		editPret->setText("");

		loadDataTable();
		});

	QObject::connect(tabel->selectionModel(), &QItemSelectionModel::selectionChanged, [&]() {
		if (tabel->selectionModel()->selectedIndexes().isEmpty()) {
			editID->setText("");
			editNume->setText("");
			editTip->setText("");
			editPret->setText("");
		}
		else {
			int row = tabel->selectionModel()->selectedIndexes().at(0).row();
			auto c1 = tabel->model()->index(row, 0);
			auto c2 = tabel->model()->index(row, 1);
			auto c3 = tabel->model()->index(row, 2);
			auto c4 = tabel->model()->index(row, 3);

			auto cel1Val = tabel->model()->data(c1, Qt::DisplayRole).toString();
			auto cel2Val = tabel->model()->data(c2, Qt::DisplayRole).toString();
			auto cel3Val = tabel->model()->data(c3, Qt::DisplayRole).toString();
			auto cel4Val = tabel->model()->data(c4, Qt::DisplayRole).toString();

			editID->setText(cel1Val);
			editNume->setText(cel2Val);
			editTip->setText(cel3Val);
			editPret->setText(cel4Val);

		
		}

		

		
		});

	QObject::connect(slider, &QSlider::valueChanged, [&]() {
		int pret = slider->value();
		qDebug() << pret;
		serv.filtrare((double)pret);

		loadDataTable();
		});

}
