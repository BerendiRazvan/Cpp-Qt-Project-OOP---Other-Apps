#include "ServApp.h"
#include <algorithm>
#include "DomainApp.h"

bool cmpPret(const Produs& p1,const Produs& p2) noexcept {
	return p1.getPret() < p2.getPret();
}

vector<Produs>& ServApp::getAllP() {
	sort(repo.getAll().begin(), repo.getAll().end(), cmpPret);
	return repo.getAll();
}

vector<Produs>& ServApp::getF() {
	return filtrat;
}

void ServApp::adaugare(int id,string nume,string tip,double pret)
{
	Produs p{id,nume,tip,pret};


	if (p.getPret() > 100.0 || p.getPret() < 1.0)
		throw exception("Pret invalid!");
	if (p.getNume() == "")
		throw exception("Nume invalid!");
	for (auto& pp : repo.getAll())
		if (p.getId() == pp.getId())
			throw exception("ID invalid!");



	repo.add(p);


}

void ServApp::filtrare(double pret)
{
	filtrat.clear();
	for (auto& p : repo.getAll())
		if (p.getPret() < pret)
			filtrat.push_back(p);
}


