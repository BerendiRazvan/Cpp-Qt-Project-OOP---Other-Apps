#include "DomainApp.h"

int Produs::getId()const
{
	return id;
}

string Produs::getNume()const
{
	return nume;
}

string Produs::getTip()const
{
	return tip;
}

double Produs::getPret()const
{
	return pret;
}

int Produs::getNrVocale()const
{
	int nr = 0;

	for (int i = 0; i < nume.size(); i++)
		if (nume[i] == 'a' || nume[i] == 'u' || nume[i] == 'o' || nume[i] == 'i' || nume[i] == 'e')
			nr++;
	
	return nr;
}
