#pragma once
#include "RepoApp.h"

class ServApp{
private:
	RepoApp& repo;
	vector<Produs> filtrat;

public:
	ServApp() = default;
	ServApp(RepoApp& repo) :repo{ repo } {};
	ServApp(const ServApp& ot) = delete;

	//fct. serv

	vector<Produs>& getAllP();

	void adaugare(int id, string nume, string tip, double pret);
	void filtrare(double pret);
	vector<Produs>& getF();
};

