#pragma once
#include "DomainApp.h"
#include <vector>

using namespace std;

class RepoApp{
private:
	vector<Produs> lista;
	string numeFis;

	void load();
	void save();

public:

	RepoApp(string numeFis) :numeFis{ numeFis } {
		load();
	};
	RepoApp(const RepoApp& ot) = delete;
	
	void add(const Produs& p);

	vector<Produs>& getAll();

};

