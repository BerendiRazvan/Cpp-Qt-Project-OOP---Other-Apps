/********************************************************************************
** Form generated from reading UI file 'OOP_Antrenament_1.ui'
**
** Created by: Qt User Interface Compiler version 6.0.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OOP_ANTRENAMENT_1_H
#define UI_OOP_ANTRENAMENT_1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_OOP_Antrenament_1Class
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *OOP_Antrenament_1Class)
    {
        if (OOP_Antrenament_1Class->objectName().isEmpty())
            OOP_Antrenament_1Class->setObjectName(QString::fromUtf8("OOP_Antrenament_1Class"));
        OOP_Antrenament_1Class->resize(600, 400);
        menuBar = new QMenuBar(OOP_Antrenament_1Class);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        OOP_Antrenament_1Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(OOP_Antrenament_1Class);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        OOP_Antrenament_1Class->addToolBar(mainToolBar);
        centralWidget = new QWidget(OOP_Antrenament_1Class);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        OOP_Antrenament_1Class->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(OOP_Antrenament_1Class);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        OOP_Antrenament_1Class->setStatusBar(statusBar);

        retranslateUi(OOP_Antrenament_1Class);

        QMetaObject::connectSlotsByName(OOP_Antrenament_1Class);
    } // setupUi

    void retranslateUi(QMainWindow *OOP_Antrenament_1Class)
    {
        OOP_Antrenament_1Class->setWindowTitle(QCoreApplication::translate("OOP_Antrenament_1Class", "OOP_Antrenament_1", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OOP_Antrenament_1Class: public Ui_OOP_Antrenament_1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OOP_ANTRENAMENT_1_H
