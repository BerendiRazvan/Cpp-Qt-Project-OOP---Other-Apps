#include "OOP_Antrenament_1.h"
#include <QtWidgets/QApplication>
#include <qpalette.h>


#include "TestApp.h"
#include "GuiApp.h"
#include "RepositoryApp.h"
#include "ServiceApp.h"


void runApp(int argc, char* argv[]) {

    QApplication a(argc, argv);

    //Repository App
    Repo repo{ "etnolog.txt","bildings.txt" };

    //Service App
    Serv serv{ repo };


    //GUI App

    for (auto& e : repo.getEtnologi()){
        GuiApp* console=new GuiApp(serv,e);
        console->show();
        console->setWindowTitle(QString::fromStdString(e.getNume()));
        
        console->setStyleSheet("background-color: yellow");

    }
    
    
    a.exec();
}

int main(int argc, char *argv[])
{
    
    //Testare App
    TestApp t{};
    t.runAllTests();

    runApp(argc,argv);

    return 0;
}
