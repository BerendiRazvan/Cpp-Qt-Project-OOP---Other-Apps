#pragma once
#include "DomainApp.h"
#include "Observer.h"
#include <vector>

using namespace std;


class Repo: public Observable {

private:
	vector<Etnolog>  etnologi;
	vector<Cladire> cladiri;

	string fisEtno;
	string fisClad;

	void loadData();
	void saveData();


public:

	Repo(string fisEtno, string fisClad) : fisEtno{ fisEtno }, fisClad{fisClad} {
		loadData();
	}


	void add(Cladire& c);
	void update(int id,string descr, string sectr,string ampl);

	vector<Cladire>& getCladiri();
	vector<Etnolog>& getEtnologi();




};