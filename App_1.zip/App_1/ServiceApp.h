#pragma once
#include "RepositoryApp.h"

class Serv {
private:

	Repo& repo;

public:

	Serv(Repo& repo) :repo{ repo } {}
	
	void addS(Cladire& c);
	void updateS(int id, string descr, string sectr,string ampl);

	vector<Cladire>& getCladiriS();
	vector<Etnolog>& getEtnologiS();

	//Returneaza referinta la repo
	Repo& adrRepo() { return repo; };
};