#include "TestApp.h"
#include <assert.h>
#include "DomainApp.h"
#include "RepositoryApp.h"
#include "ServiceApp.h"
#include <fstream>
#include <qdebug.h>

using namespace std;

void testDomain() {
	
}

void testRepo() {

}

void testServ() {
	

}


void TestApp::runAllTests()
{
	testDomain();
	testRepo();
	testServ();



	qDebug() << "All tests passsed";

}
