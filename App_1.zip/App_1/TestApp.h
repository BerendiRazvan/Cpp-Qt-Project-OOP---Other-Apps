#pragma once
class TestApp
{
public:

	//fct. care ruleaza toate testele
	void runAllTests();

};

