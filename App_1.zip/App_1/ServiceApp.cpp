#include "ServiceApp.h"
#include <algorithm>


bool cmp(Cladire& c1, Cladire& c2) {
	return c1.getSector() < c2.getSector();
}

void Serv::addS(Cladire& c)
{
	for (auto& cc : repo.getCladiri())
		if (cc.getID() == c.getID())
			throw exception("Adaugare imposibila, id invalid");
	if (c.getDescr() == "")
		throw exception("Adaugare imposibila, descriere invalid");
	repo.add(c);
}

void Serv::updateS(int id, string descr, string sectr, string ampl)
{
	int ok = 0;
	for (auto& cc : repo.getCladiri())
		if (cc.getID() == id)
			ok = 1;

	if (ok == 0)
		throw exception("Adaugare imposibila, id invalid");

	for (auto& cc : repo.getCladiri())
		if (cc.getID() == id && cc.getSector() != sectr)
			throw exception("Update imposibil, nu este sectorul dumneavoastra");

	repo.update(id, descr, sectr, ampl);
}

vector<Cladire>& Serv::getCladiriS() {
	sort(repo.getCladiri().begin(), repo.getCladiri().end(), cmp);
	return repo.getCladiri();
}


vector<Etnolog>& Serv::getEtnologiS() {
	return repo.getEtnologi();
}