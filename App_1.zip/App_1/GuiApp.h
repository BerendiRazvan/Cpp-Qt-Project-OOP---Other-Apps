#pragma once
#include <qwidget.h>

#include "Observer.h"
#include "ServiceApp.h"
#include <qabstracttablemodel>
#include <qstring.h>
#include <qtableview.h>
#include <qlayout.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qmessagebox.h>
#include <qpushbutton.h>
#include <qobject.h>

class MyModel: public QAbstractTableModel {
private:
	
	vector<Cladire> listaC;
	Serv& serv;

public:
	Etnolog& e;
	MyModel() = default;
	MyModel(Serv& serv, Etnolog& e) :serv{ serv }, listaC{ serv.getCladiriS() }, e{e}{	};

	int rowCount(const QModelIndex& parent=QModelIndex()) const override {

		return listaC.size();
	}

	int columnCount(const QModelIndex& parent = QModelIndex()) const override {
		return 4;
	}

	QVariant data(const QModelIndex& index = QModelIndex(),int role=Qt::DisplayRole) const override {
		if (role == Qt::DisplayRole) {
			Cladire j = listaC[index.row()];
			if (index.column() == 0)
				return j.getID();

			if (index.column() == 1)
				return QString::fromStdString(j.getDescr());

			if (index.column() == 2)
				return QString::fromStdString(j.getSector());

			if (index.column() == 3)
				return QString::fromStdString(j.getLoc());

			

		}

		if (role == Qt::BackgroundRole) {
			Cladire pr = listaC[index.row()];
			if (pr.getSector() == e.getCladire()) {
				return QBrush(Qt::blue);
			}
			else {
				return QBrush(Qt::white);
			}

		}

	
		return QVariant{};
	}

	void setJocuri(const vector<Cladire>& j) {
		listaC = j;

		QModelIndex topLeft = createIndex(0,0);
		QModelIndex bottumRight = createIndex(rowCount(),columnCount());

		emit dataChanged(topLeft,bottumRight);
		emit layoutChanged();
	
	}


};




class GuiApp: public QWidget, public Observer
{
private:
	
	Etnolog& e;
	Serv& serv;
	QHBoxLayout* lyMain = new QHBoxLayout;
	QTableView* tabel = new QTableView;
	MyModel* model = new MyModel(serv,e);

	QPushButton* btnadd = new QPushButton("&Add");
	QPushButton* btnupdate = new QPushButton("&Update");

	QLabel* lblId= new QLabel;
	QLabel* lblDecr= new QLabel;
	QLabel* lblSect = new QLabel;
	QLabel* lblLoc = new QLabel;


	QLineEdit* leId = new QLineEdit;
	QLineEdit* leDecr = new QLineEdit;
	QLineEdit* leSect= new QLineEdit;
	QLineEdit* leLoc = new QLineEdit;
	int id = -1;
	
	//initializeaza GUI
	void initGUI();

	//initializeaza conexiuni GUI
	void initConnection();

	//incarca datele
	void loadData();

	void update()override {
		loadData();
	}

public:
	//operatii clasa
	GuiApp() = default;
	GuiApp(Serv& serv, Etnolog& e) :serv{ serv }, e{e} {
		serv.adrRepo().addObserver(this);
		initGUI();
		initConnection();
		loadData();
	}
	~GuiApp() {
		serv.adrRepo().removeObserver(this);
	}

};

