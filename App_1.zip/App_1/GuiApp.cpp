#include "GuiApp.h"


void GuiApp::initGUI() {
	tabel->setSelectionBehavior(QAbstractItemView::SelectRows);
	tabel->setModel(model);
	resize(1300, 500);
	
	setLayout(lyMain);

	lyMain->addWidget(tabel);
	QVBoxLayout* lyDr = new QVBoxLayout;
	lyMain->addLayout(lyDr);
	QVBoxLayout* lySt = new QVBoxLayout;
	lblId->setText("ID:");
	lblDecr->setText("DESCRIERE:");
	lblSect->setText("SECTOR:");
	lblLoc->setText("LOCATIE:");
	leSect->setText(QString::fromStdString(e.getCladire()));
	leSect->setReadOnly(true);

	lySt->addWidget(lblId);
	lySt->addWidget(leId);
	lySt->addWidget(lblDecr);
	lySt->addWidget(leDecr);
	lySt->addWidget(lblSect);
	lySt->addWidget(leSect);
	lySt->addWidget(lblLoc);
	lySt->addWidget(leLoc);


	lySt->addWidget(btnadd);
	lySt->addWidget(btnupdate);
	lyMain->addLayout(lySt);



	

}


void GuiApp::initConnection() {

	

	QObject::connect(btnadd, &QPushButton::clicked, [&]() {
		if (leId->text() == "" || leDecr->text() == "" || leSect->text() == "" || leLoc->text() == "") {
			QMessageBox::information(nullptr, "Info adaugare", "Datele nu pot fi nule");
		}
		else {
			
			Cladire c{stoi(leId->text().toStdString()),leDecr->text().toStdString(),leSect->text().toStdString(),leLoc->text().toStdString() };
			try {
				serv.addS(c);
			}
			catch (exception& ex) {
				QMessageBox::information(nullptr, "Info adaugare", ex.what());
			}
			loadData();
		}

		leId->setText("");
		leDecr->setText("");
		leSect->setText(QString::fromStdString(e.getCladire()));
		leLoc->setText("");

		id = -1;

		});

	QObject::connect(btnupdate, &QPushButton::clicked, [&]() {
		if (leDecr->text() == "" || leSect->text() == "" || leLoc->text() == "") {
			QMessageBox::information(nullptr, "Info update", "Datele nu pot fi nule");
		}
		else {
			try {
			serv.updateS(stoi(leId->text().toStdString()), leDecr->text().toStdString(), leSect->text().toStdString(), leLoc->text().toStdString());
			}
			catch (exception& ex) {
				QMessageBox::information(nullptr, "Info update", ex.what());
			}
			loadData();
		}

		leId->setText("");
		leDecr->setText("");
		leSect->setText(QString::fromStdString(e.getCladire()));

		leLoc->setText("");

		id = -1;

		});

	

}

void GuiApp::loadData() {
	model->setJocuri(serv.getCladiriS());
}
