#pragma once

#include <string>


using namespace std;



class Etnolog {
private:
	string nume, cladire;

public:
	Etnolog(string nume, string cladire) :nume{ nume }, cladire{ cladire }{};

	string getNume() { return nume; }
	string getCladire() { return cladire; }

	void setNume(string a) { nume = a; }
	void setCladire(string a) { cladire = a; }



};


class Cladire {
private:
	int id;
	string descriere, sector, locatie;

public:
	Cladire(int id, string descriere, string sector, string locatie) :id{ id }, descriere{ descriere }, sector{ sector }, locatie{locatie}{};

	int getID() { return id; }
	string getDescr() { return descriere; }
	string getSector() { return sector; }
	string getLoc() { return locatie; }
	
	void setDescr(string a) { descriere = a; }
	void setSector(string a) { sector = a; }
	void setLoc(string a) { locatie = a; }

};
