#include "OOP_Antrenament_1.h"

OOP_Antrenament_1::OOP_Antrenament_1(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
