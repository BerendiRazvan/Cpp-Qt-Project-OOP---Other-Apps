#include "RepositoryApp.h"
#include <fstream>
#include <exception>

using namespace std;

void Repo::loadData() {
	ifstream inE(fisEtno);
	ifstream inC(fisClad);

	if (!inE.is_open() || !inC.is_open())
		throw exception("Error deschidere fisiere");

	while (!inE.eof()) {
		string nume, cladire;
	
		if (inE.eof())break;
		getline(inE, nume, ';');

		if (inE.eof())break;
		getline(inE, cladire, '\n');

		Etnolog e{nume,cladire};

		etnologi.push_back(e);
	
	}

	while (!inC.eof()) {
		string id, descr,sect , loc;

		if (inC.eof())break;
		getline(inC, id, ';');

		if (inC.eof())break;
		getline(inC, descr, ';');

		if (inC.eof())break;
		getline(inC, sect, ';');

		if (inC.eof())break;
		getline(inC, loc, '\n');


		Cladire c{ stoi(id),descr,sect,loc };
		cladiri.push_back(c);

	}


	inE.close();
	inC.close();
}



void Repo::saveData() {
	ofstream outE(fisEtno);
	ofstream outC(fisClad);

	for (auto& e : etnologi)
		outE << e.getNume()<<";"<<e.getCladire()<<"\n";

	for (auto& c : cladiri)
		outC << c.getID() << ";" << c.getDescr() << ";" << c.getSector() << ";" << c.getLoc() << "\n";

	outE.close();
	outC.close();

}


vector<Cladire>& Repo::getCladiri() {

	return cladiri;
}


vector<Etnolog>& Repo::getEtnologi() {
	return etnologi;
}

void Repo::add(Cladire& c) {
	cladiri.push_back(c);
	saveData();
	notify();
}

void Repo::update(int id, string descr, string sectr,string ampl) {
	for(auto& c:cladiri)
		if (c.getID() == id) {
			c.setDescr(descr);
			c.setLoc(ampl);
		}

	saveData();
	notify();
}