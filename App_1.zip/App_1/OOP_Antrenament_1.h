#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_OOP_Antrenament_1.h"

class OOP_Antrenament_1 : public QMainWindow
{
    Q_OBJECT

public:
    OOP_Antrenament_1(QWidget *parent = Q_NULLPTR);

private:
    Ui::OOP_Antrenament_1Class ui;
};
