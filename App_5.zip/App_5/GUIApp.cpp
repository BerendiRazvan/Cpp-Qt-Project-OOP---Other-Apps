#include "GUIApp.h"

void GUIApp::intiGui()
{
	tabel->setSelectionBehavior(QAbstractItemView::SelectRows);
	tabel->setModel(model);
	resize(1000, 500);


	QHBoxLayout* lyMain = new QHBoxLayout;
	setLayout(lyMain);
	lyMain->addWidget(tabel);

	QVBoxLayout* lyDr = new QVBoxLayout;
	lyMain->addLayout(lyDr);

	lblId->setText("ID Task:");
	lblDescriere->setText("Descriere:");
	lblProgramatori->setText("Programatori:");
	lblStare->setText("Stare (open/inprogress/closed):");

	lyDr->addWidget(lblId);
	lyDr->addWidget(leId);

	lyDr->addWidget(lblDescriere);
	lyDr->addWidget(leDescriere);

	lyDr->addWidget(lblProgramatori);
	lyDr->addWidget(leProgramatori);

	lyDr->addWidget(lblStare);
	lyDr->addWidget(leStare);

	lyDr->addStretch();

	lyDr->addWidget(btnAdd);
	lyDr->addWidget(btnCautare);


}

void GUIApp::initConnection()
{
	QObject::connect(tabel->selectionModel(), &QItemSelectionModel::selectionChanged, [&]() {
		if (tabel->selectionModel()->selectedIndexes().isEmpty()){
			leId->setText("");
			leDescriere->setText("");
			leProgramatori->setText("");
			leStare->setText("");
		}
		else {
			int row = tabel->selectionModel()->selectedIndexes().at(0).row();
			
			auto c1 = tabel->model()->index(row, 0);
			auto c2 = tabel->model()->index(row, 1);
			auto c3 = tabel->model()->index(row, 2);

			auto  val1 = tabel->model()->data(c1,Qt::DisplayRole).toString();
			auto  val2 = tabel->model()->data(c2, Qt::DisplayRole).toString();
			auto  val3 = tabel->model()->data(c3, Qt::DisplayRole).toString();
			
			leId->setText(val1);
			leDescriere->setText(val2);
			leStare->setText(val3);

			int id = stoi(val1.toStdString());
			string prog;
			for(auto& t:serv.getAllT())
				if (t.getId() == id) {
					prog = t.getProgramatori();
					break;
				}

			leProgramatori->setText(QString::fromStdString(prog));
		
		}
		
		});


	QObject::connect(btnAdd, &QPushButton::clicked, [&]() {
		if (leId->text()=="" || leDescriere->text() == "" || leProgramatori->text() == "" || leStare->text() == "") {
			leId->setText("");
			leDescriere->setText("");
			leProgramatori->setText("");
			leStare->setText("");

			QMessageBox::information(nullptr,"Info adaugare","Campurile nu pot fi goale, selectati un task sau complectati");
		}
		else {

			try {
				serv.adaugare(stoi(leId->text().toStdString()), leDescriere->text().toStdString(), leProgramatori->text().toStdString(), leStare->text().toStdString());
			}
			catch (exception& ex) {
				QMessageBox::information(nullptr,"Adaugate Info",ex.what());
			}

			loadData(serv.getAllT());
		}

		leId->setText("");
		leDescriere->setText("");
		leProgramatori->setText("");
		leStare->setText("");

		});

	QObject::connect(btnCautare, &QPushButton::clicked, [&]() {
		if (leProgramatori->text() == "") {

			leProgramatori->setText("");
			loadData(serv.getAllT());
			QMessageBox::information(nullptr, "Info cautare", "Tabelul a fost resetat");
		}
		else {

			loadData(serv.cautarePr(leProgramatori->text().toStdString()));
		}

		leId->setText("");
		leDescriere->setText("");
		leProgramatori->setText("");
		leStare->setText("");

		});


}

void GUIApp::loadData(const vector<Task>& tasksss)
{
	model->setTasks(tasksss);
}
