#include "OOP_Practic_Antrenament4.h"
#include <QtWidgets/QApplication>

#include "TestApp.h"
#include "RepositoryApp.h"
#include "ServiceApp.h"
#include "GUIApp.h"


void runApp(int argc, char* argv[]) {

    QApplication a(argc, argv);
    
    //Repository App
    RepositoryApp repo{ "data.txt" };

    //Seervice App
    ServiceApp serv{ repo };

    //GUI App
    GUIApp console{ serv };
    console.show();


    a.exec();
}



int main(int argc, char *argv[])
{
    //Testare App
    TestApp teste{};
    teste.runAllTests();

    runApp(argc,argv);

    return 0;
}
