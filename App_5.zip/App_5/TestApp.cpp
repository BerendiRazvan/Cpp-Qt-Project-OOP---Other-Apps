#include "TestApp.h"
#include <qdebug.h>
#include <assert.h>

#include "DomainApp.h"
#include "RepositoryApp.h"
#include "ServiceApp.h"


void testDomain() {


}

void testRepo() {


}

void testService() {


}


void TestApp::runAllTests()
{
	testDomain();
	testRepo();
	testService();

	qDebug() << "All tests passed";
}
