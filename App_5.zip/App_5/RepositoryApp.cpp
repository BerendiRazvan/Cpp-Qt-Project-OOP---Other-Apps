#include "RepositoryApp.h"
#include <fstream>
#include <exception>


using namespace std;



void RepositoryApp::load()
{
    ifstream in(numeF);
    if (!in.is_open())
        throw exception("Fiserul pt. citire nu se poate deschide");
    while (!in.eof()) {
        string id, d, p, s;
        if (in.eof())break;
        getline(in,id,';');

        if (in.eof())break;
        getline(in, d, ';');

        if (in.eof())break;
        getline(in, p, ';');

        if (in.eof())break;
        getline(in, s, '\n');

        Task t{stoi(id),d,p,s};
        
        lista.push_back(t);

    }

    in.close();
}

void RepositoryApp::save()
{
    ofstream out(numeF);
    if (!out.is_open())
        throw exception("Fiserul pt. scriere nu se poate deschide");

    for (auto& t : lista)
        out << t.getId() << ";" << t.getDescriere() << ";" << t.getProgramatori() << ";" << t.getStare() << "\n";

    out.close();
}

vector<Task>& RepositoryApp::getAll()
{
    return lista;
}

void RepositoryApp::add(const Task& t)
{
    lista.push_back(t);
    save();
}
