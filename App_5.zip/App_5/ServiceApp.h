#pragma once
#include "RepositoryApp.h"


class ServiceApp{
private:
	RepositoryApp& repo;

	vector<Task> filtr;
public:
	ServiceApp() = default;
	ServiceApp(RepositoryApp& repo) :repo{ repo } {};
	ServiceApp(const ServiceApp& ot) = delete;

	//fct. service
	
	vector<Task>& getAllT();
	void adaugare(int id,string d,string p,string s);
	vector<Task>& cautarePr(string pr);
};

