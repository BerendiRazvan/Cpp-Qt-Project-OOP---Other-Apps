#pragma once
#include "ServiceApp.h"


#include <qlayout.h>
#include <qwidget.h>
#include <QAbstractTableModel>
#include <qstring.h>
#include <qtableview.h>
#include <qmessagebox.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qobject.h>


class MyModel :public QAbstractTableModel {
private:
	vector<Task> lista;
	ServiceApp& serv;

public:

	MyModel() = default;
	MyModel(ServiceApp& serv) :serv{ serv }, lista{serv.getAllT()} {}

	int rowCount(const QModelIndex& parent=QModelIndex()) const override {
		return lista.size();
	}

	int columnCount(const QModelIndex& parent = QModelIndex()) const override {
		return 4;
	}

	QVariant data(const QModelIndex& index=QModelIndex(),int role=Qt::DisplayRole) const override {
		if (role == Qt::DisplayRole) {
			Task t = lista[index.row()];

			if (index.column() == 0)
				return t.getId();
		
			if (index.column() == 1)
				return QString::fromStdString(t.getDescriere());

			if (index.column() == 2)
				return QString::fromStdString(t.getStare());

			if (index.column() == 3) {
				int nr=1;
				for (int i = 0; i < t.getProgramatori().size(); i++)
					if (t.getProgramatori()[i] == ' ')
						nr++;
				return nr;
			}

		}

		return QVariant{};
	}

	void setTasks(const vector<Task>& t) {
		lista = t;

		QModelIndex topLeft = createIndex(0,0);
		QModelIndex bottumRight = createIndex(rowCount(), columnCount());

		emit dataChanged(topLeft,bottumRight);
		emit layoutChanged();
	}


};



class GUIApp:public QWidget{
private:
	ServiceApp& serv;

	QTableView* tabel = new QTableView;
	MyModel* model = new MyModel(serv);

	QLabel* lblId = new QLabel;
	QLabel* lblDescriere = new QLabel;
	QLabel* lblProgramatori = new QLabel;
	QLabel* lblStare = new QLabel;

	QLineEdit* leId = new QLineEdit;
	QLineEdit* leDescriere = new QLineEdit;
	QLineEdit* leProgramatori = new QLineEdit;
	QLineEdit* leStare = new QLineEdit;

	QPushButton* btnAdd = new QPushButton("&Adaugare");
	QPushButton* btnCautare = new QPushButton("&Cautare");


	void intiGui();
	void initConnection();
	void loadData(const vector<Task>& tasksss);

public:

	GUIApp() = default;
	GUIApp(ServiceApp& serv) :serv{ serv } { 
		intiGui();
		initConnection();
		loadData(serv.getAllT());
	}
	GUIApp(const GUIApp& ot) = delete;



};

