#include "OOP_Practic_Antrenament4.h"

OOP_Practic_Antrenament4::OOP_Practic_Antrenament4(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
