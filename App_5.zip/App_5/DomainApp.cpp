#include "DomainApp.h"

int Task::getId()
{
    return id;
}

string Task::getDescriere()
{
    return descriere;
}

string Task::getProgramatori()
{
    return programatori;
}

string Task::getStare()
{
    return stare;
}

void Task::setStare(string s)
{
    stare = s;
}
