#pragma once

#include "DomainApp.h"
#include <vector>

using namespace std;


class RepositoryApp{
private:
	vector<Task> lista;
	
	string numeF;

	void load();
	void save();



public:

	RepositoryApp() = default;
	RepositoryApp(string numeF) :numeF{ numeF } { load(); }
	RepositoryApp(const RepositoryApp& ot) = delete;

	vector<Task>& getAll();

	void add(const Task& t);
	void update();


};

