#include "ServiceApp.h"
#include <algorithm>

bool cmp(Task& t1, Task& t2) {
    return t1.getStare() < t2.getStare();
}

vector<Task>& ServiceApp::getAllT()
{
    sort(repo.getAll().begin(),repo.getAll().end(),cmp);
    return repo.getAll();
}

void ServiceApp::adaugare(int id, string d, string p, string s)
{
    
    for (auto& m : repo.getAll()) {
        if (m.getId() == id)
            throw exception("ID Invalid");
    }

    if (d == "")
        throw exception("Descriere Invalida");

    if(s!="open"&&s!="inprogress"&&s!="closed")
        throw exception("Stare Invalida");
    int nr = 1;
    if (p == "")nr = 0;
    for (int i = 0; i < p.size(); i++)
        if (p[i] == ' ')
            nr++;
   if(nr<1)
       throw exception("Prea putini programatori");
   if (nr > 4)
       throw exception("Prea multi programatori");

   Task t{ id,d,p,s };
   repo.add(t);

}

vector<Task>& ServiceApp::cautarePr(string pr)
{
    filtr.clear();
    
    for (auto& t : repo.getAll()) {
        if (t.getProgramatori().find(pr) != string::npos)
            filtr.push_back(t);
    }


    return filtr;
}
