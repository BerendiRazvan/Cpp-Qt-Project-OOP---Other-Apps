#pragma once
#include <string>

using namespace std;

class Task{
private:
	int id;
	string descriere, programatori, stare;

public:
	Task() = default;
	Task(int id, string descriere, string programatori, string stare): id{ id }, descriere{ descriere }, programatori{ programatori }, stare{ stare }{}

	int getId();
	string getDescriere();
	string getProgramatori();
	string getStare();

	void setStare(string s);


};

